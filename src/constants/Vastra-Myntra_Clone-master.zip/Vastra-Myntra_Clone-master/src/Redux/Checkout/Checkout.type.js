export const GET_CHECKOUT_SUCCESS='get/Success';
export const GET_CHECKOUT_LOADING='get/Loading';
export const GET_CHECKOUT_ERROR='get/Error';


//ADD_TYPE
export const ADD_CHECKOUT_PRODUCT='add/Checkout';


//DELETE_TYPE
export const DELETE_CHECKOUT_PRODUCT='delete/Checkout';