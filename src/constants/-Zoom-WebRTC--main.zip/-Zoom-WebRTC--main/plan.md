# Plan of action

- Initialize our NodeJS Project ---Done
- Initialize our first view ---Done
- Create a room id --- Done
- Add ability to view our own video ---Done
- Add ability to allow others to stream their video  --Done
- Add styling --Done
- Add ability to create messages --Done
- Add mute button --Done
- Add stop video button --Done
- Deploy
    * npm install -g heroku
    * add .gitignore
    * add node_modules to .gitignore
    * change port to 443 and add process.env.PORT
    * push to github or heroku
        % pushing to heroku
            -- git init
            -- git add .
            -- git commit -m "commit message"
            -- heroku create
            -- git push heroku master/main
            -- heroku ps:scale web=1
            -- heroku open